clear;

imds = imageDatastore('MRI_600','IncludeSubfolders',true,'LabelSource','foldernames');
[imdsTrain,imdsTest] = splitEachLabel(imds,0.7,'randomized');

numTrainImages = numel(imdsTrain.Labels);
idx = randperm(numTrainImages,16);

%Transfer Model
net = inceptionv3;

inputSize = net.Layers(1).InputSize;
%analyzeNetwork(net)

augimdsTrain = augmentedImageDatastore(inputSize(1:2),imdsTrain, 'ColorPreprocessing','gray2rgb');
augimdsTest = augmentedImageDatastore(inputSize(1:2),imdsTest, 'ColorPreprocessing','gray2rgb');

layer = 'loss3-classifier';
featuresTrain = activations(net, augimdsTrain, layer, 'OutputAs', 'rows');
featuresTest = activations(net, augimdsTest, layer, 'OutputAs', 'rows');

% Combine Train and Test Features
Feature = [featuresTrain;featuresTest];

% Labels
YTrain = imdsTrain.Labels;
YTest = imdsTest.Labels;

% Combine Train and Test Labels
Labels = [YTrain;YTest];

%Transpose the Train Features and Labelsl
Feature = Feature';
Labels = Labels';


% The CNN Output is feeded to Autoencoder for Dimension reduction
% AutoEncoder 1
% Training a sparse autoencoder on the training data without using the labels.
hiddenSize1 = 512;
autoenc1 = trainAutoencoder(Feature, hiddenSize1, ...
    'MaxEpochs',100, ...
    'L2WeightRegularization',0.004, ...
    'SparsityRegularization',4, ...
    'SparsityProportion',0.15, ...
    'ScaleData', false);

%view(autoenc1)
%figure(1)
%plotWeights(autoenc1);

% Features Level 1
feat1 = encode(autoenc1, Feature);


% AutoEncoder 2
hiddenSize2 = 256;
autoenc2 = trainAutoencoder(feat1,hiddenSize2, ...
    'MaxEpochs',100, ...
    'L2WeightRegularization',0.002, ...
    'SparsityRegularization',4, ...
    'SparsityProportion',0.1, ...
    'ScaleData', false);

%view(autoenc2)
%figure(2)
%plotWeights(autoenc2);

% Features Level 2
feat2 = encode(autoenc2,feat1);

% % The original vectors in the training data had 1024 dimensions. 
% % After passing them through the first encoder, this was reduced to 512 dimensions. 
% % After using the second encoder, this was reduced again to 256 dimensions. 
% % You can now train a final layer to classify these 256-dimensional vectors into different classes.
% 
% % Training the final softmax layer
% 
%softnet = trainSoftmaxLayer(feat2, tTrain,'MaxEpochs', 400);
%view(autoenc1)
%view(autoenc2)
%view(softnet)
stackednet = stack(autoenc1,autoenc2);
view(stackednet)



% Store the Features reTranspose
feat2 = feat2';
Labels = Labels'; 

% Categorical to Numerical Labels
%c = categorical({'AD','CN','EMCI','LMCI','MCI'});
%n = grp2idx(c);
nLabel = zeros(size(Labels,1),1);
for i=1:size(Labels,1)
   if (Labels(i) == "AD")
   nLabel(i) = 1;
   end
   if (Labels(i) == "CN")
   nLabel(i) = 2;
   end
   if (Labels(i) == "EMCI")
   nLabel(i) = 3;
   end
   if (Labels(i) == "LMCI")
   nLabel(i) = 4;
   end
   if (Labels(i) == "MCI")
   nLabel(i) = 5;
   end
end

%Results
finalFeatures = [feat2 nLabel];
writematrix(finalFeatures,'googlenet_mri_600.txt','delimiter','\t')






% % Get the number of pixels in each image
% imageWidth = 28;
% imageHeight = 28;
% inputSize = imageWidth*imageHeight;
% 
% % Load the test images
% [xTestImages,tTest] = digitTestCellArrayData;
% 
% % Turn the test images into vectors and put them in a matrix
% xTest = zeros(inputSize,numel(xTestImages));
% for i = 1:numel(xTestImages)
%     xTest(:,i) = xTestImages{i}(:);
% end
% 
%y = stackednet(xTest);
%plotconfusion(tTest,y);



