#import warnings
#warnings.filterwarnings("ignore")
import numpy as np
import pandas
from tensorflow import keras
from tensorflow.keras import layers
from keras.models import Sequential
from keras.layers import Dense, Activation
from keras.utils.np_utils import to_categorical
from keras.utils.vis_utils import plot_model
from sklearn.model_selection import train_test_split
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline
from matplotlib import pyplot
from sklearn.metrics import roc_curve, auc

# seed for reproducing same results
seed = 0
np.random.seed(seed)

# load pima indians dataset
dataset = np.loadtxt('res_mri_600.csv', delimiter=',', skiprows=0)

dim = 256
cop = 5

# split into input and output variables
X = dataset[:,0:dim].astype(float)
Y = dataset[:,dim]

## encode class values as integers

encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)

## convert integers to dummy variables (i.e. one hot encoded)
Y1 = np_utils.to_categorical(encoded_Y)

# Direct Conversion - no need now
#Y1 = to_categorical(Y)

# Checking the Dimension
#print(dataset.shape)
#print(X)
#print(X.shape)
#print(Y1.shape)
#print(Y1)

# split the data into training (70%) and testing (30%)
(X_train, X_test, Y_train, Y_test) = train_test_split(X, Y1, test_size=0.95, random_state=seed)


#model.add(Dense(8, input_dim=8, init='uniform', activation='relu'))
#model.add(Dense(6, init='uniform', activation='relu'))
#model.add(Dense(1, init='uniform', activation='sigmoid'))

# create the model
model = Sequential()

model.add(Dense(256, input_dim = dim))
model.add(Activation(activation='relu'))

# Hidden - Layers
model.add(layers.Dense(128, activation = "relu"))
model.add(layers.Dense(64, activation = "relu"))
model.add(layers.Dense(512, activation = "relu"))

model.add(layers.Dense(64, activation = "relu"))
model.add(layers.Dense(128, activation = "relu"))
model.add(layers.Dense(64, activation = "relu"))
model.add(layers.Dense(512, activation = "relu"))
model.add(layers.Dense(64, activation = "relu"))


#model.add(layers.Dropout(0.2, noise_shape=None, seed=None))
#model.add(layers.Dense(256, activation = "relu"))
#model.add(layers.Dropout(0.2, noise_shape=None, seed=None))
#model.add(layers.Dense(256, activation = "sigmoid"))
#model.add(layers.Dropout(0.2, noise_shape=None, seed=None))
#model.add(layers.Dense(256, activation = "relu"))

model.add(Dense(cop))
model.add(Activation(activation='sigmoid'))

opt = keras.optimizers.Adam(learning_rate=0.01)

model.compile(optimizer=opt, loss='categorical_crossentropy', metrics=['accuracy'])

# fit the model
history = model.fit(X_train, Y_train, validation_data=(X_test, Y_test), epochs=10, batch_size=32, verbose=2)

# plot learning curves
#pyplot.plot(history.history['categorical_accuracy'], label='train')
#pyplot.plot(history.history['val_categorical_accuracy'], label='test')
#pyplot.title('momentum ='+ str(momentum), pad=-80)


# Plot ROC - 5 Class
import numpy as np
from scipy import interp
import matplotlib.pyplot as plt
from itertools import cycle
from sklearn.metrics import roc_curve, auc

#plot the train accuracy and loss graph
#Plot training & validation accuracy values
#print(history.history)

plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model Accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')
plt.savefig('accuracy.png', dpi=300, bbox_inches='tight')
#plt.show()
plt.clf()

# Plot training & validation loss values
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model Loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')
plt.savefig('loss.png', dpi=300, bbox_inches='tight')
#plt.show()
plt.clf()

print('\n')
print('\n')
print('************ Test Data Accuracy & Loss ************')
print('\n')

# evaluate the model
scores = model.evaluate(X_test, Y_test)
print("Test Accuracy: %.2f%%" % (scores[1]*100))
print("Test Loss: %.2f%%" % (scores[0]))


print('\n')
print('************ Model Summary ************')
print('\n')

# model summary & score for Xtest data
model.summary()
y_score = model.predict(X_test) 
#print(X_test.shape)
#print(y_score)
#print(y_score.shape)

n_classes = Y1.shape[1]
#print(n_classes)
y_score = model.predict(X_test) 
#print(y_score)
y_test = Y_test


# Plot linewidth.
lw = 2

# Compute ROC curve and ROC area for each class
fpr = dict()
tpr = dict()
roc_auc = dict()
for i in range(n_classes):
    fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# Compute micro-average ROC curve and ROC area
fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

# Compute macro-average ROC curve and ROC area

# First aggregate all false positive rates
all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))

# Then interpolate all ROC curves at this points
mean_tpr = np.zeros_like(all_fpr)
for i in range(n_classes):
    mean_tpr += interp(all_fpr, fpr[i], tpr[i])

# Finally average it and compute AUC
mean_tpr /= n_classes

fpr["macro"] = all_fpr
tpr["macro"] = mean_tpr
roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])

# Plot all ROC curves
plt.figure(1)
'''
plt.plot(fpr["micro"], tpr["micro"],
         label='micro-average ROC curve (area = {0:0.2f})'
               ''.format(roc_auc["micro"]),
         color='deeppink', linestyle=':', linewidth=4)

plt.plot(fpr["macro"], tpr["macro"],
         label='macro-average ROC curve (area = {0:0.2f})'
               ''.format(roc_auc["macro"]),
         color='navy', linestyle=':', linewidth=4)
'''

colors = cycle(['aqua', 'darkorange', 'green', 'red', 'magenta'])
class_names = cycle(['Alzheimer Disease', 'Control Normal', 'Early MCI', 'Late MCI', 'MCI'])
for i, color, class_name in zip(range(n_classes), colors, class_names):
    plt.plot(fpr[i], tpr[i], color=color, lw=lw,
             label='Class : {} (area = {:.2f})'
             ''.format(class_name, roc_auc[i]))

plt.plot([0, 1], [0, 1], 'k--', lw=lw)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve for Multi class')
plt.legend(loc="lower right")
#plt.show()
plt.savefig('roc_mclass.png', dpi=300, bbox_inches='tight')
#plt.show()
plt.clf()


# Zoom in view of the upper left corner.
plt.figure(2)
plt.xlim(0, 0.3)
plt.ylim(0.8, 1.01)
'''
plt.plot(fpr["micro"], tpr["micro"],
         label='micro-average ROC curve (area = {0:0.2f})'
               ''.format(roc_auc["micro"]),
         color='deeppink', linestyle=':', linewidth=4)

plt.plot(fpr["macro"], tpr["macro"],
         label='macro-average ROC curve (area = {0:0.2f})'
               ''.format(roc_auc["macro"]),
         color='navy', linestyle=':', linewidth=4)
'''

colors = cycle(['aqua', 'darkorange', 'green', 'red', 'magenta'])
class_names = cycle(['Alzheimer Disease', 'Control Normal', 'Early MCI', 'Late MCI', 'MCI'])
for i, color, class_name in zip(range(n_classes), colors, class_names):
    plt.plot(fpr[i], tpr[i], color=color, lw=lw,
             label='Class {} : {}'
             ''.format(i, class_name))

plt.plot([0, 1], [0, 1], 'k--', lw=lw)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve for Multi class ')
plt.legend(loc="lower right")
#plt.show()
plt.savefig('roc_mclass_zoom.png', dpi=300, bbox_inches='tight')
#plt.show()
plt.clf()


print('\n')
print('************ ROC Curve Area ************')
print('\n')


# ROC Curve Area 
class_names = ['Alzheimer Disease', 'Control Normal', 'Early MCI', 'Late MCI', 'MCI']
for i, class_name in zip(range(n_classes), class_names):
    label='ROC curve of class : {} (area = {:.2f})'.format(class_name, roc_auc[i])
    print(label)

mlabel1='macro-average ROC curve (area = {0:0.2f})'.format(roc_auc["macro"])
mlabel2='micro-average ROC curve (area = {0:0.2f})'.format(roc_auc["micro"])
print('\n')
print(mlabel1)
print(mlabel2)
print('\n')



print('\n')
print('************ Confusion Matrix ************')
print('\n')

#from sklearn.metrics import confusion_matrix
#cm = confusion_matrix(y_test, y_score)
#print(encoder.classes_)
#= y_score
#print(encoder.inverse_transform(y_score[1,:]))
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test.argmax(axis=1), y_score.argmax(axis=1))
print(cm)

import itertools
class_names = ['Alzheimer Disease', 'Control Normal', 'Early MCI', 'Late MCI', 'MCI']

figure = plt.figure(figsize=(8, 8))
plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
plt.title("Confusion matrix")
plt.colorbar()
tick_marks = np.arange(len(class_names))
plt.xticks(tick_marks, class_names, rotation=45)
plt.yticks(tick_marks, class_names)

# Normalize the confusion matrix.
cm = np.around(cm.astype('float') / cm.sum(axis=1)[:, np.newaxis], decimals=2)

# Use white text if squares are dark; otherwise black.
threshold = cm.max() / 2.

for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
    color = "white" if cm[i, j] > threshold else "black"
    plt.text(j, i, cm[i, j], horizontalalignment="center", color=color)
    
plt.tight_layout()
plt.ylabel('True Class')
plt.xlabel('Predicted Class')
plt.savefig('confusion_matrix.png', dpi=300, bbox_inches='tight')
#plt.show()
plt.clf()

print('\n')
print('************ Performance Measure - Classification Report ************')
print('\n')
# Classification Report
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score
from sklearn.metrics import log_loss
target_names = ['Alzheimer Disease', 'Control Normal', 'Early MCI', 'Late MCI', 'MCI']
print(classification_report(y_test.argmax(axis=1), y_score.argmax(axis=1), target_names=target_names))
